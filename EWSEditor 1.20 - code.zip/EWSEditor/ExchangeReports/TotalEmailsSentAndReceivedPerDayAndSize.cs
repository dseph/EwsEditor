﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EWSEditor.ExchangeReports
{
    public partial class TotalEmailsSentAndReceivedPerDayAndSize : Form
    {
        public TotalEmailsSentAndReceivedPerDayAndSize()
        {
            InitializeComponent();
        }

        private void TotalEmailsSentAndReceivedPerDayAndSize_Load(object sender, EventArgs e)
        {
            // Total Emails Sent and Received Per Day and Size
            // https://gallery.technet.microsoft.com/f2af711e-defd-476d-896e-8053aa964bc5
        }
    }
}
