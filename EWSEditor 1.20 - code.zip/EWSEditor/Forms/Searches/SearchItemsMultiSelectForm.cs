﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EWSEditor.Forms.Searches
{
    public partial class SearchItemsMultiSelectForm : Form
    {
        public SearchItemsMultiSelectForm()
        {
            InitializeComponent();
        }

        private void cmboUidConditional_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void SearchItemsMultiSelectForm_Load(object sender, EventArgs e)
        {

        }
    }
}
