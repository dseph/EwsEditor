﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EWSEditor.Common.UtilityHelpers
{
    class IcsHelper
    {
        // https://github.com/trevorcrupi/ICal-Parser
        // https://github.com/der-Daniel/ical.NET 
        // https://msdn.microsoft.com/en-us/library/office/dd633665(v=exchg.80).aspx
        // https://msdn.microsoft.com/en-us/library/office/dn726695(v=exchg.150).aspx
        //https://sourceforge.net/projects/icalparser/
        
        // http://severinghaus.org/projects/icv/
    }
}
