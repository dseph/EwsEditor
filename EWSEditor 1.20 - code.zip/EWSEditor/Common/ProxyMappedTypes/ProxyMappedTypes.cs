﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
 

namespace EWSEditor.Common
{
   
    public enum CreateActionType
    {
        CreateNew,

        Update,

        UpdateOrCreate,


    }
}