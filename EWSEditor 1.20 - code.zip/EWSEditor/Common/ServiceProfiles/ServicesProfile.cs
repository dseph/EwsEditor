﻿namespace EWSEditor.Common.ServiceProfiles
{
    
    
    public partial class ServicesProfile {
    }
}
